# Third-party notices — OSource 0.4.0

OSource's original code, branding and editorial illustrations are MIT licensed. That does not change third-party licenses, trademarks or software terms.

## Runtime/build dependencies included in the compiled program

| Component | Resolved version | License | Upstream |
|---|---|---|---|
| Go runtime/standard library | go1.27.3 build toolchain | BSD-3-Clause | https://go.dev/ |
| go-webview2 | v0.0.0-20260205173254-56598839c808 | MIT | https://github.com/jchv/go-webview2 |
| go-winloader | v0.0.0-20250406163304-c1995be93bd1 | ISC | https://github.com/jchv/go-winloader |
| bbolt | v1.5.0 | MIT | https://go.etcd.io/bbolt |
| golang.org/x/sys | v0.49.0 | BSD-3-Clause | https://pkg.go.dev/golang.org/x/sys |
| golang.org/x/net | v0.61.0 | BSD-3-Clause | https://pkg.go.dev/golang.org/x/net |
| golang.org/x/image | v0.47.0 | BSD-3-Clause | https://pkg.go.dev/golang.org/x/image |
| Microsoft WebView2Loader SDK component | embedded by resolved go-webview2 | Microsoft copyright, BSD-style redistribution notice | See actual `docs/licenses/WebView2Loader.txt` |
| Inter font, latin variable WOFF2 | Google Fonts Inter v20 distribution | SIL Open Font License 1.1 | https://rsms.me/inter/ |

The **complete license texts** are in `docs/licenses/` (installed binary distribution: `licenses/`). The MIT/ISC/BSD notices and font license must accompany redistribution. `go.mod` and `go.sum` are the authoritative resolved module inputs.

The separately installed **Microsoft Edge WebView2 Evergreen Runtime** is not included in this distribution and is governed by Microsoft's runtime terms. OSource's MIT license does not license that runtime. OSource offers to open the official Microsoft download page when it is missing; it does not download or install it silently.

## Build and test tools
- NSIS Modern UI creates the installer. NSIS's installer stub is distributed under its permissive license; see `docs/licenses/NSIS.txt`. NSIS itself is not installed onto the user's PC as a development tool.
- `go-winres v0.3.3` and its `winres` tooling generate icon/version/manifest resources. They are build tools, not linked into OSource. See their upstream repositories and pinned build script command.
- Playwright/Chromium are used for development browser checks and are not shipped in the app. Their upstream licenses apply to those development installations.
- Python/Pillow were used to export installer/icon artwork and are not part of the application runtime.

## Catalog data and third-party marks
Project names, descriptions, avatars, source code and release assets belong to their original creators. Repository data is retrieved from GitHub's public API under the applicable GitHub terms. Owner avatars may differ from actual app icons. License badges report known SPDX metadata returned by GitHub; they are not a license audit or a security endorsement.

The curated website directory is editorial. It includes both source-linked projects and free-to-use services. No claim is made that every listed website is open-source, ad-free or account-free. Website thumbnails now use thum.io captures or actual publisher OpenGraph/Twitter images. These images belong to their respective owners; they are not relicensed under OSource’s MIT license. Legacy editorial artwork remains in the source assets but is not represented as a live screenshot.

OSource is not affiliated with or endorsed by Microsoft, GitHub, Reddit, FMHY, AlternativeTo, SourceForge, F-Droid, or any listed project. Referenced third-party trademarks remain the property of their respective owners.

## Live discovery and thumbnail providers
- GitHub public REST API: https://docs.github.com/en/rest
- FMHY published directory: https://fmhy.net/ and https://github.com/fmhy/edit (selected tools/education sections, original attribution links retained).
- Reddit public RSS: https://www.reddit.com/r/opensource/ and https://www.reddit.com/r/webgames/ (recent discussion references, not an endorsement).
- Open VSX Registry: https://open-vsx.org/ (extensions and publisher metadata; review each extension license).
- **Data provided by FreeToGame:** https://www.freetogame.com/api-doc (free-to-play listings, not an open-source license statement).
- thum.io: https://www.thum.io/ and https://www.thum.io/documentation/api/url (public cached screenshots; availability/terms can change).
- Publisher-provided OpenGraph/Twitter images are fetched only as an optional thumbnail fallback.

OSource does not bundle these remote catalogs or grant rights to redistribute their linked content. APIs, published feeds and original HTTPS files are requested on demand with caching, bounded requests and explicit denial/rate-limit handling. No credentials, access-control bypass or private-data collection is included. Listings are not safety or legal-rights verification.

## Community picks (0.3.0)
The new bundled collection contains editorial summaries and links to actual public Reddit recommendation threads, not copied comment archives. Each listing retains an original source URL. Publisher names, images, software and websites remain subject to their owners’ rights and terms. Free-to-use does not imply open source or freedom from third-party advertising. See `docs/COMMUNITY-PICKS.md` and the machine-readable provenance in `docs/research/community-picks.json`. No new runtime dependency was added in 0.3.0.

## Additional sources (0.4.0)
- VibeTopList RPG directory: https://vibetoplist.com/category/rpg · terms: https://vibetoplist.com/terms · robots: https://vibetoplist.com/robots.txt. Up to two permitted public pages are requested with 12-hour caching. No voting, ad units, callbacks, credentials or private APIs. Directory rankings can reflect paid boosts; they are not OSource endorsements.
- Foundplay official games API: https://foundplay.io/api/games · specification: https://foundplay.io/openapi.json · integration guidance: https://foundplay.io/connect · terms: https://foundplay.io/terms. API requests are capped at 25 results/query, cached and linked back to Foundplay. No bulk listing/cover scrape or mirrored catalog is bundled. The API's documented response window is not treated as unlimited pagination. Unnecessary `utm_*` parameters are removed from displayed canonical listing links, retaining the link back.
- aviaryan/awesome-ai-games: https://github.com/aviaryan/awesome-ai-games · public README is parsed on demand. List attribution does not transfer licenses/rights to the linked games or guarantee that remakes are authorized. No repository images or game binaries are bundled.
- User-requested r/Piracy wiki: https://www.reddit.com/r/Piracy/wiki/megathread/ · external link only, not imported. Automated access returned HTTP 403 during integration. No alternate host, proxy, authentication bypass or wiki scraping is used.

These sources and game publishers retain their own rights, terms and trademarks. OSource is independent of them. No new runtime dependency was added in 0.4.0.
