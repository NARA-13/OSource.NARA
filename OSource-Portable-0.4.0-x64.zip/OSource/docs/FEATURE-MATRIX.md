# OSource 0.4.0 — implementation boundaries

This matrix is a handoff record, not a claim that the entire original specification is complete.

| Area | Implemented in source/artifact | Boundary or follow-up |
|---|---|---|
| Windows distribution | x64 PE GUI executable, icon/version/manifest resources, NSIS per-user installer, portable ZIP | Unsigned; cross-compiled; Windows 10/11 execution and installation not tested here |
| Desktop host | WebView2 embedded window, native controls, minimum size, runtime preflight, active-transfer close confirmation | Requires Evergreen Runtime; no tray mode, startup registration, saved window geometry |
| Branding | Original open-window/code mark, wordmark, transparent and monochrome SVGs, multi-resolution ICO, installer art | No trademark clearance or external brand audit performed |
| Navigation | Exactly Home, All Apps, Store, Websites, Settings, About & Credits | Downloads and search are overlays, not extra primary sections |
| Home | Live editorial-project metadata, local favorite ordering, recent activity, collections, website favorites, quick actions, optional onboarding | Not a machine-learning recommendation system; stars are not a universal popularity or safety score |
| Library | Best-effort registry/Start Menu detection, native import, reference launch, folder open, favorites, custom collections, filters, sorts, grid/list | Native paths not runtime-tested here; no icon extraction; no automatic executable-target resolution for shortcuts |
| App management | Explicit opening of completed installers; import/detect app afterward | No silent install, package manager, dependency resolution, managed uninstall, install-completion detection or automatic update tracking |
| Store data | Eight-adapter live discovery and one external reference, saved discoveries, GitHub project/license/release metadata and assets | No invented projects; editorial selection is static but all repository metadata is fetched live/cached; source-scoped counts and pagination; GitHub caps each query at 1,000 |
| Search/filter | Global/local search, public repo lookup, favorites, source/kind filters, relevance/star/update sorting; per-release architecture/platform/package filters | Architecture/portable hints inferred from names; unsupported attributes remain Unknown; no catalog-wide verified Windows compatibility index |
| Detail views | Metadata, license, original sources, release dates, sizes, release notes, compatibility caveats | Official pages provide screenshots/full instructions/system requirements; none fabricated |
| Downloads | HTTPS-only official GitHub release assets, queue, bounded concurrency, real progress/speed/ETA, pause/resume/cancel/retry, history | Resume depends on server behavior; when Range unsupported a clean restart occurs; manual source adapters beyond GitHub not enabled |
| Integrity | Size, basic header, SHA-256 and supplied release digest checks; Windows Authenticode inspection; explicit rehash before launch | Signature is not a safety guarantee. No independent malware scanning. Windows checks not runtime-tested here |
| Windows security | Internet-zone marker, native launch consent, standard ShellExecute | Existing Windows prompts remain enabled; NTFS ADS marking can be unavailable on other filesystems |
| Websites | 28 Reddit-sourced website picks, existing saved websites, classifications, live directory, source links, collections, Surprise me preview, browser opening, custom sites and provenance-preserving bookmarks | Optional real page captures/publisher images with opt-out; not live video or an availability monitor; some captures fail |
| Discovery sources | GitHub API, FMHY, Reddit RSS, Open VSX, FreeToGame, VibeTopList RPG pages, Foundplay API and Awesome AI Games README; external r/Piracy wiki | Reddit is recent-feed filtering only; r/Piracy wiki is external-only; Foundplay 25/query; VibeTopList first two RPG pages; FMHY ten tools/education sections; external AlternativeTo/SourceForge/F-Droid references are not adapters; F-Droid is Android-only |
| Appearance | Light/dark/system, full accent-derived palette, finite transitions and feedback with OS/app reduced-motion support, spacing, corner radius, scale, sidebar collapse, reduced motion | No custom background image/color engine, transparency, particles, gradient/effect editor or animation-intensity control |
| Typography | Bundled Inter, installed-font list on Windows, text/interface scaling | Font enumeration can include registry face names that rely on normal font fallback; no font-weight UI |
| Sounds | Off-by-default action chime, volume and manual preview | One synthesized profile; no separate OS notification sound system |
| Download settings | Folder and concurrency, fixed-on verification/consent protections | No automatic installer deletion, native notifications or proxy UI |
| Privacy/storage | Local bbolt state and cache; optional recent history; no telemetry; record/cache clear; full JSON export; settings import/export | General library data re-import is not implemented. Logical cache clearing does not necessarily shrink bbolt files. Full data directory deletion requires closing the app |
| Offline | Persistent library/preferences and stale metadata fallback; transfers fail clearly | Offline avatars may not load if not already cached by WebView; no first-run bundled metadata pretending to be live |
| Onboarding | Skippable theme/accent/download-location introduction; embedded loading screen | No mandatory registration or setup |
| About/support | Actual dependency notices, privacy/security/changelog, independent-source statement | No supplied public repo, issue tracker, security contact, signing identity or update feed; UI does not invent them |
| Tests | Go security/state/cache/download/race tests; live real-file test; Chromium browser-flow tests; cross-build and PE/NSIS checks | Native Windows launch, detection, file selection, Authenticode, installer/uninstaller and SmartScreen checks remain outstanding |

## Release gate before production distribution

1. Run the Windows checklist on clean Windows 10 and 11 x64 machines.
2. Review native operations, accessibility, DPI behavior and network edge cases.
3. Establish an owned repository, issue tracker, private disclosure address, signed update policy and code-signing identity.
4. Obtain a security review of the local service, download pipeline and dependency update policy.
5. Decide whether the deferred advanced features are necessary for the next release; do not enable decorative controls that do nothing.

Community picks are a small dated editorial collection, not an automatic megathread importer. Live Reddit remains recent-public-feed filtering. The 12 community desktop projects route to separately fetched official GitHub releases; recommendation provenance is not verification.
