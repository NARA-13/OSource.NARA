# Architecture

## Why Go + WebView2
The environment could cross-compile a self-contained Go Windows host without a Windows SDK, MSVC, CGo, Electron runtime or browser window. WebView2 supplies a maintained Windows rendering engine. The release executable embeds all first-party interface files and the Inter font. It depends on the installed WebView2 runtime, which launches its own normal rendering processes; no claim of a single-process renderer or measured RAM target is made.

## Request lifecycle
`main.go` opens a per-user bbolt database, generates a process-local API token, and starts the local service. In native mode the listener is loopback-only, with strict Host validation. The host navigates WebView2 to this service and keeps the Win32 message loop on its OS thread. Browser-facing requests use relative `/api/` paths; no external frontend service or hardcoded localhost port is needed. Native APIs are invoked in the backend, never in remote web pages.

The service serves embedded assets with CSP, no-sniff and no-referrer headers. No user supplied raw HTML is rendered. First-party assets work offline. Allowlisted publisher icons are external UI assets; optional website images are proxied through authenticated local thumbnail requests.

## Local state
The `local` bucket holds a backward-compatible JSON snapshot inside a bbolt transaction. State updates are serialized with a Go mutex; cache operations use separate bbolt transactions. Downloads checkpoint progress approximately every two seconds. An interrupted active record becomes paused on startup. Preferences are immediate, not delayed until exit.

This schema is intentionally small. Future schema changes should add a schema version and tested transactional migrations before changing field meaning. Unknown JSON fields are currently ignored. The default data directory is per-user; a concurrent process cannot open the same bbolt database normally.

## Catalog adapter
`SourceAdapter` defines Search and Project. `GitHub` implements both using the official public REST API, not HTML scraping. Search returns repository records. Details combine repository data with `/releases/latest`. A small editorial list of **real repository identifiers** defines the featured selection; descriptions/licenses/versions are not invented offline seed data.

Cache keys are request paths, with a fetch timestamp and raw JSON. Search/repository TTL is six hours; latest stable release TTL is one hour. Failed refreshes return stale cached data when possible. Rate limits produce an explicit user error when no cache exists. Adding another adapter requires defining trust policy, record mapping, download provenance and terms-of-service handling, not merely adding a logo to the UI.

## Downloads
The scheduler starts up to the configured number of workers. Each worker streams to disk, reporting actual received bytes and interval speed to shared state. No file is held entirely in memory. Context cancellation pauses/cancels transfers. Range requests use validators where available. Unsupported Range falls back to truncation and restart.

Final verification blocks a new pause/cancel request while the file is being hashed and classified. Final state includes the calculated SHA-256 and Windows signature result. Main shutdown stops scheduling, cancels transfers and waits for workers before closing the database. Signature inspection has a 15-second timeout.

Uninstall/install completion is intentionally outside this download state machine. An installer exiting or a file disappearing cannot reliably tell OSource whether an app was installed successfully. Imported/detected references are separate records.

## Windows integration
`platform_windows.go` implements:
- WebView2 availability check and native window creation.
- Active-transfer confirmation at WM_CLOSE.
- Native file picker for `.exe` / `.lnk` import.
- Supported uninstall-registry/Start Menu detection.
- Current-user ShellExecute opening of apps, folders and explicit external HTTPS URLs.
- Installed font enumeration.
- Authenticode metadata via PowerShell and Internet-zone marker writing.

`platform_other.go` is an explicit development stub. It never attempts to launch the Linux sandbox's apps or pass commands from a remote preview to its shell.

## Frontend
The UI is a dependency-free six-section SPA. Semantic buttons, focus-visible states, modal focus trapping, grouped keyboard search, reduced-motion support and responsive breakpoints are included. Catalog/detail loading and errors have explicit states. Downloads are polled only while active or while their drawer is visible. There are no fake time-based progress bars.

## Known engineering follow-ups
Native Windows runtime tests, exhaustive accessibility/contrast audits, icon extraction, window placement persistence, cache pruning/compaction, large-catalog virtualization (pagination is implemented), richer typed state migrations and a formally reviewed signed updater remain future work. See FEATURE-MATRIX.md and WINDOWS-TEST-CHECKLIST.md.

## Multi-source discovery (0.2.0)
`discovery.go` concurrently requests eligible adapters, interleaves their records and deduplicates URLs per response. The UI deduplicates appended pages by stable ID. All-source pages request 12/source; single-source pages request 30. GitHub limits each query to its API’s 1,000-result window. Source counts/scopes stay separate.

Raw RSS/Markdown/JSON responses are JSON-string-encoded inside the persistent cache, avoiding invalid `json.RawMessage` storage for non-JSON inputs. Cache namespace v3 supersedes invalid legacy raw-cache entries. Forbidden/rate-limited hosts have persisted deadlines. FMHY and feed/game filtering is local after a cached fetch. See DISCOVERY.md for TTLs and limits.

`previews.go` provides single-flight, two-worker website capture with a 24-hour bounded filesystem cache. Blank captures and errors trigger actual public publisher-image fallback. A disabled setting is enforced server-side. There is no synthetic image fallback. The frontend derives surface tokens from the chosen accent hue and serializes preference writes to avoid out-of-order saves.

## Community and motion (0.3.0)
`community-data.js` is generated from `docs/research/community-picks.json`; 28 websites and 12 desktop project references keep source thread URLs. `community.js` provides local collection filtering, paging, previews, bookmarks and source details, separately from the live RSS adapter. `Website.sourceUrl/sourceTitle` are optional backward-compatible fields validated as public HTTPS and escaped on display.

Navigation reuses the existing shell rather than rebuilding the sidebar on each page change. `motion.js` watches newly inserted UI surfaces and applies bounded Web Animations to visible elements, capped at 12 cards and five stagger delays. It does not schedule a permanent rendering loop. CSS handles hover/press/save/image feedback. Both app and OS reduced-motion controls disable transitions and cancel running animations. The UI has no parallax, custom cursor, autoplay showcase or decorative gradient.

## Additional game sources (0.4.0)
`game_sources.go` adds VibeTopList's bounded, robots-checked RPG HTML reader, the official Foundplay JSON API, the Awesome AI Games README parser and a network-free external wiki reference. Discovery has eight adapters plus that reference. The reference has no numeric inventory count and emits its one directory record only when explicitly selected. All-source browsing does not blend it into the live item stream.

The optional `DiscoveryItem.browser` flag denotes a source-described browser game; it is not an executable or license verification. It survives bookmarks and enables Add to Websites. Foundplay's `total` is a source-reported match count; only the returned window of at most 25 records can be locally paged. VibeTopList and Awesome AI Games counts cover their fetched/parsed snapshots. No synthetic count is appended to inflate inventory.
