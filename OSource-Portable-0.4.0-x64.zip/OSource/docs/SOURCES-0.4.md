# Requested sources — OSource 0.4.0

Integrated on **2026-10-26**. These are real source adapters or an explicitly labeled external reference, not a new static invented catalog. Existing preferences, personal bookmarks, community picks, six primary sections and consent-based downloads remain intact.

## Integration summary

| Requested source | Implemented behavior | Actual integration observation |
|---|---|---|
| [VibeTopList RPG](https://vibetoplist.com/category/rpg) | Read up to two allowed public RPG pages, parse title/description/tags/banner, cache 12 hours, filter/page locally. | 27 RPG listings parsed from two pages. This is **not** all 272 games advertised by the site. |
| [Foundplay](https://foundplay.io/) | Use the documented public `/api/games` API, query/sort, at most 25 records, one-hour cache, attribution links. | Broad query: 25 returned out of 1,824 reported matches. Racing: 25 returned out of 129. The API does not document offset/cursor paging; no invented paging is used. |
| [Awesome AI Games](https://github.com/aviaryan/awesome-ai-games) | Parse actual `#### [game](https://...)` headings and descriptions from the public main-branch README; 12-hour cache, local search/page. | 30 browser-game links. Neither repo license nor Windows compatibility is inferred for linked games. |
| [r/Piracy megathread](https://www.reddit.com/r/Piracy/wiki/megathread/) | External directory reference only, available when explicitly selected. No automatic requests or contents imported by this reference. | Automated access returned **HTTP 403**. No bypass attempted; no numeric inventory count claimed. |

Counts change upstream. Results can overlap across catalogs; matching totals are not installed applications or safety checks. See `test-logs/live-sources-0.4.0.json` and `test-logs/game-sources-browser-0.4.0.txt` for executed evidence.

## Where to find them
- **Store → source picker:** VibeTopList · RPG, Foundplay, Awesome AI Games, r/Piracy wiki (external).
- **Websites → Explore:** compact source shortcuts, opening the selected source in Store.
- **Websites → Live directory:** corresponding source options. For VibeTopList, this view includes only listings whose source tags explicitly mention a browser, not all RPGs or desktop/mobile games.
- Save records with the heart; saved metadata and source provenance persist and remain searchable. Browser-described games can be added to My websites.
- Foundplay/VibeTopList open their original listing pages. Awesome AI Games opens the original browser game, keeping the README source link. The wiki opens its exact supplied Reddit URL. These are not automatic download/install actions.

## Source policy and limits

### VibeTopList
Reviewed [terms](https://vibetoplist.com/terms), [robots policy](https://vibetoplist.com/robots.txt) and [API documentation](https://vibetoplist.com/api-docs). The public API docs are primarily about votes/callbacks; `/api/` is disallowed in robots, so OSource does **not** use it. The RPG category pages are the permitted HTML source.

The adapter checks the current robots policy before reading category pages, fails closed on unreadable/stale rules, and pauses for an explicit crawl-delay requirement. It performs no votes, logins, ad clicks, callbacks, user harvesting or broad crawl. It reads at most page 1 and page 2, with a 2 MiB page limit and 12-hour cache. Local query and original source order are used; the global sort control is not interpreted as a new ranking engine. Source rankings can reflect paid boosts. A listed game may be paid, free-to-start, unfinished, mobile-only, desktop-only or otherwise unsuitable. Source tags are not independent verification.

### Foundplay
Reviewed [integration documentation](https://foundplay.io/connect), [OpenAPI specification](https://foundplay.io/openapi.json), [terms](https://foundplay.io/terms) and [robots policy](https://foundplay.io/robots.txt). Its terms explicitly permit apps to recommend games through the public API with links back and within limits, while prohibiting bulk scraping/republishing without permission. Therefore the adapter uses that API only, not the HTML browse-page scraper considered during initial inspection.

Only `q`, `sort` and `limit=25` are sent. Updated maps to `new`; other sorts use `popular`. Results must link to `foundplay.io/games/`. Canonical backlink destinations are retained; unnecessary `utm_*` parameters are removed. No tracked `/go/` redirect is requested by the adapter. An initial direct default-client request for the OpenAPI document was denied; the documentation remained readable through the page tool and a normal request to the separately documented public games API succeeded. No access-control evasion or alternate host was used.

In All sources, local 12-item pages subdivide those 25 returned records. Selecting Foundplay alone shows up to 25; it does not promise to load every reported match. Narrow a query or open Foundplay for more. No automatic full-site crawl, bulk cover download or complete mirrored catalog is bundled.

### Awesome AI Games
Uses the official raw [README](https://raw.githubusercontent.com/aviaryan/awesome-ai-games/main/README.md), not an invented API or copied fixed inventory. Table-of-contents links, tweet references, auxiliary source-code links and images are not converted into additional games. The parser rejects non-HTTPS/private-address targets, preserves source attribution and distinguishes an unrecognized format from a genuine empty query result. Source descriptions of AI creation, remakes and originals are not a legal-rights, licensing, safety or affiliation audit.

### Reddit wiki
The named wiki is a separate reference from the existing live r/opensource/r/webgames RSS adapter. A denial is not permission to use a proxy, alternate Reddit host or access-control bypass. The wiki is labeled **external reference / not indexed**, with no fabricated game/app count and no automatic download route. Inclusion of the user-requested link does not certify the rights or safety of its contents. Use only content you are entitled to access.

## Retained security and privacy
All adapter requests use the existing public-address-validated HTTPS transport, bounded response sizes, source caching and persisted 403/429 cooldowns. New-source queries sent to Foundplay are disclosed in PRIVACY.md; VibeTopList and Awesome AI Games filter locally. Optional detail thumbnails retain the existing opt-out and cache controls. Game metadata is rendered as escaped text. Managed file downloads are still restricted to independently resolved GitHub releases, with explicit consent and integrity checks; no directory link is automatically promoted into an installer.

No new runtime dependency, login, telemetry endpoint or advertising SDK was added. Native Windows installation/launch testing remains outstanding; successful cross-compilation and Chromium tests are not Windows-runtime evidence.
