# OSource privacy statement — 0.4.0

## No OSource account or tracking service
OSource has no account system, telemetry implementation, advertising SDK, subscription service or cloud synchronization. It does not ask for passwords. It does not inspect user documents to build recommendations.

## Local records
The default Windows directory is `%LOCALAPPDATA%\OSource`, overridable with `--data`. It contains a bbolt database, a local log file and the WebView2 profile. Records include preferences, explicit app file references, best-effort detected app references, favorites, custom websites, optional recent activity, download records and saved discovery metadata, source caches and optional thumbnail files.

The library detector reads supported uninstall-registry fields and Start Menu shortcuts. It is not a scan of all personal files. The file picker reads the selected path; launching uses that reference. Download records include paths and original source URLs. JSON exports can contain personal filesystem paths; review before sharing them.

Recent activity is optional and local. Turning it off stops new recording; clear existing activity separately. There is no separate persisted search-history feature, but API queries and their results are cached, potentially beyond their normal TTL as offline fallback. Clear the API cache to remove those logical entries.

## Network contacts
- `api.github.com`: repository search, license metadata and releases. GitHub receives your public IP address and queries. No access token is embedded or required.
- `github.com` release assets and their public HTTPS redirect destinations: actual file transfers.
- `avatars.githubusercontent.com`: project-owner images, loaded by the embedded UI.
- `raw.githubusercontent.com`: published FMHY tools/education directory files.
- `www.reddit.com`: public recent RSS feeds; queries filter those fetched posts locally.
- `open-vsx.org`: extension search queries and publisher icons; images may be unavailable if a CDN is outside the UI allowlist.
- `www.freetogame.com`: game catalog and publisher thumbnails; query filtering is local.
- `image.thum.io`: public website URLs for optional cached screenshot capture. Website previews default to enabled, including after upgrade from 0.1.0; disable in Settings → Privacy. Public paths are sent; query strings, fragments, credentials, ports and private-network targets are excluded. The provider sees the public IP and target URL and has its own retention policy.
- Public website publishers/CDNs: if a screenshot fails or is blank, OSource may fetch the public page and its OpenGraph/Twitter image. No browser cookies, credentials or user browsing profile are forwarded. Only public HTTPS requests are allowed. Image requests are bounded; some providers/sites will fail.
- Official or custom websites you explicitly open: launched in the default browser and governed by their own terms. Some free third-party services may contain advertisements.
- Microsoft WebView2 is a separately installed runtime governed by Microsoft's terms and servicing behavior. OSource does not reimplement or promise to disable all runtime/OS-level network behavior.

## Thumbnail retention
Local previews expire after 24 hours, with a 200-image/64 MiB bound and at most two concurrent captures. No-store response headers avoid a separate browser-image cache; Settings → Privacy → Clear previews deletes local preview files. This cannot erase a provider’s own cache or previously received URL. Disabling previews stops new app-requested captures; it does not recall requests already in flight. Cached images are not a live-availability monitor.

## Retention and erasure
Preferences and records persist until removed. No scheduled remote upload occurs. Settings provides record/cache clearing, JSON export and a local-record reset. Logical database deletion may leave free pages within the database file; it is not forensic secure erasure.

Record clearing never removes installed applications or personal documents. Erasing OSource records does not delete downloaded/partial files, local logs or WebView profile files. To remove all OSource local data, close the app and remove its complete data directory. Delete unwanted downloaded files separately. The uninstaller deliberately preserves these locations.

## Security context
OSource normally runs as the current user, without elevation. Another process running as the same user can access that user's files and is not isolated by this application. See SECURITY.md for the local-service and download threat model.

## Community picks
The 40 attributed references bundled in 0.3.0 can be filtered locally without sending the query to Reddit. They are a dated editorial selection, not an automatically synced feed. Clicking a Reddit source or website opens it externally. Enabled thumbnails still contact the preview providers described above. Surprise me opens a local detail dialog, not an unsolicited browser tab. Saved website records can retain a public recommendation URL/title; these are included in local data exports.

## New source contacts in 0.4.0
- `vibetoplist.com`: current robots policy and up to two public RPG listing pages. Visible game-banner images can load from the same host. Queries filter cached metadata locally; no votes, ad clicks, logins or private APIs are requested.
- `foundplay.io`: public `/api/games` requests with search text, sort and `limit=25`; results are cached for one hour. Listing links remain on Foundplay. No `/go/` click-tracking or sponsored redirect is fetched by the adapter, and no account is required.
- `raw.githubusercontent.com`: the public `aviaryan/awesome-ai-games/main/README.md`. Queries filter its cached browser-game links locally.
- The r/Piracy wiki reference itself makes **no background Reddit request**. Its exact supplied URL opens only when you choose to open the wiki. The separate existing Reddit RSS adapter can still contact Reddit when selected or used in All sources.

Opening game details may request a still website preview if thumbnails are enabled, under the existing privacy rules. Source metadata includes the original listing/directory URL for attribution. No bulk remote catalog is included in the release archives; provider caches remain in your local data directory.
