# OSource 0.4.0 — test report

Date: **2026-10-26**. Execution environment: Linux sandbox, Go 1.27.3, Node.js 20.20.2, headless Chromium via Playwright, NSIS 3.

## Result summary

| Test area | Result | Evidence / scope |
|---|---|---|
| Go deterministic test suite | PASS | 37 top-level deterministic tests plus 6 failure subcases; separate opt-in live test also passed; `go test -race -v ./...` |
| Go race detector | PASS on exercised paths | No data races reported by the test suite or live test; not proof that every untested path is race-free |
| Go static analysis | PASS | `go vet ./...` and Windows/amd64-targeted `go vet ./...` |
| Windows x64 cross-compilation | PASS | GUI-subsystem PE32+ x86-64 executable, embedded resources and all first-party UI assets |
| NSIS packaging | PASS | Actual installer compiled; static archive extraction succeeded and embedded executable SHA-256 matched the standalone executable |
| Real GitHub metadata | PASS | Public repository and stable release metadata retrieved without a token/account |
| Real Windows file download | PASS | Official `jqlang/jq` release, actual executable bytes, matching supplied SHA-256; never executed |
| Full UI download flow | PASS | Live search → repository details → asset selection → visible-source confirmation → queue → real download → verified completed record |
| Browser functional flows | PASS | Six sections, favorites/persistence, live release details, architecture filter, source consent, search keyboard, custom websites, themes, native-only error feedback, About limitations |
| Responsive browser layout | PASS on tested widths | 1380 px desktop, 960 px minimum-width layout, 520 px narrow layout; no horizontal overflow in checked Home states |
| Full-accent theme regression | PASS | Blue backgrounds/navigation/cards/controls, visible Settings, light/dark, alternate accent and persisted selection |
| Live multi-source discovery | PASS | Five sources, genuine source counts, partial-failure fixtures, paging, bookmark persistence, Ctrl+K, website query and in-flight query retention |
| Website previews | PARTIAL availability; graceful failure PASS | Excalidraw capture and Radio Garden publisher image loaded; Neal.fun correctly showed Unavailable. Opt-out and cache-clear checked |
| Community pick structure/provenance | PASS | 28 website/12 project references; valid HTTPS thread URLs, unique IDs, classifications; bookmark attribution persists; invalid source URLs rejected |
| Community UI | PASS | Collection filter/search, non-launching Surprise me, save/reload, global search, provenance-preserving My websites, app release route, 12/24/28 progressive loading |
| Motion and reduced motion | PASS in Chromium | Navigation shell retained; finite entrances/hover, no idle ambient loop; app toggle and emulated OS preference disable effects; 960/520 px layout |
| Additional source integration | PASS | 27 actual VibeTopList RPG records; Foundplay returned 25 of 1,824 reported matches and 25 of 129 for racing; Awesome AI Games parsed 30 links. Counts are observations, not fixed inventory promises. |
| Robots/API/reference boundaries | PASS | Robots rule precedence and stop-before-fetch; bounded two-page cache; Markdown classification; API 25-window local paging; network-free external wiki; new-source bookmark persistence |
| Source browser flows | PASS | Four source shortcuts, real source selection/query, release/download distinction, save/reload/global search, wiki external-only state, Websites integration and narrow layout |
| Browser runtime errors | PASS | No JavaScript `pageerror` events during tested flows |
| Windows 10/11 actual execution | **NOT RUN** | No Windows system or working Windows WebView2 runtime was available in this Linux environment |
| Windows installer/uninstaller execution | **NOT RUN** | Packaging was compiled and inspected, not installed on Windows |
| Native file dialogs, detection, launching, Authenticode, zone marking, SmartScreen, DPI | **NOT RUN** | Implemented and Windows-target compiled; requires the attached native acceptance checklist |

## Real downloaded asset

- Repository: `https://github.com/jqlang/jq`
- Stable release returned by GitHub during testing: `jq-1.8.2`
- Asset: `jq-windows-amd64.exe`
- Downloaded bytes: **1,035,264**
- Calculated SHA-256: `a6fc67fedaf9128a3309a1e2ebb8b986aeccf70122ee46d2cb4849e423f0c627`
- Digest comparison: **matched the GitHub release asset digest**
- Execution: **NO**. The native/installer run action was never invoked for the downloaded file.

This is evidence of download/integrity behavior, not evidence that the downloaded third-party software is safe, or a Windows installation test.

## Deterministic coverage
- Trusted-source URL and HTTPS validation; rejection of deceptive hosts, userinfo, private-network URLs and non-release URLs.
- Public-address screening, including private, loopback, link-local, shared/benchmark and documentation address ranges.
- Remote filename sanitization.
- Windows asset and architecture/package-name classification.
- State persistence, favorite/library restoration and interrupted-transfer recovery to paused.
- Local history opt-out.
- Request-token, Origin and native-host checks.
- Metadata caching and stale offline fallback with simulated transport failure.
- Real file writes using harmless non-executable test fixture bytes, size and hash verification.
- HTTP Range and If-Range resume with controlled server responses.
- Safe truncation/restart when a simulated server ignores Range.
- Explicit rejection of checksum mismatch, HTML response, size mismatch, HTTP 404, invalid range and incorrect file header.
- Context cancellation.
- Preference persistence and rejection of out-of-range settings.
- Preview execution refusal.

## New deterministic coverage in 0.2.0
- RSS/Markdown/JSON byte-for-byte persistent cache round trips.
- Persisted 403/429 cooldown: a recreated adapter does not refetch before its deadline.
- FMHY primary-link parsing, source attribution and repository classification.
- GitHub query paging and 1,000-result boundary.
- Reddit posts classified as discussions, with cached-feed/local-filter behavior.
- Open VSX extensions and FreeToGame free-to-play game classification.
- Partial source failure preserves other results.
- Saved-discovery metadata and favorite persistence.
- Thumbnail URL privacy restrictions, authentication and disabled-setting enforcement.
- Blank/oversized/invalid image rejection and public publisher metadata parsing.

Source-scale observations are recorded in DISCOVERY.md. Repository totals are not a 200,000+ verified Windows app test. Screenshots are real Linux Chromium preview captures, not Windows execution evidence.

## 0.3.0 evidence
`go-0.3.0.txt`, `browser-0.3.0.txt`, `community-browser-0.3.0.txt`, `discovery-browser-0.3.0.txt` and `download-browser-0.3.0.txt` in `test-logs/` record the executed checks. Windows and Linux `go vet` passed. Public data changed between runs; source counts are not fixed inventory assertions. Community references were found in public search-indexed threads; direct Reddit/website access can still be blocked. Structural validation is not an audit of every linked website, comment, license or app.

## 0.4.0 evidence
Executed logs: `go-0.4.0.txt`, `browser-0.4.0.txt`, `community-browser-0.4.0.txt`, `discovery-browser-0.4.0.txt`, `game-sources-browser-0.4.0.txt` and `download-browser-0.4.0.txt`. `live-sources-0.4.0.json` stores status/count evidence and two example names per source, not a bulk mirror. Source/terms review and scope are documented in SOURCES-0.4.md. Live all-source browsing returned 96 records from eight catalogs plus a separate external-reference status. No wiki import or Windows-native execution is implied.

## Important interpretation
Resume/failure edge cases use a controlled in-process HTTP transport so they are repeatable. The separate live test uses real HTTPS requests and real official release bytes. Browser tests run the embedded UI in Chromium; they do not validate Win32 dialogs, Windows ShellExecute, actual WebView2 browser-download export behavior or the NSIS installation experience.

All native Windows tasks remain **pending**, not inferred as passing from the successful cross-build. See WINDOWS-TEST-CHECKLIST.md. A complete, audited production release would require those tests and additional robustness/accessibility/security review.

Raw executed-test output is in `docs/test-logs/` in the source distribution. The release artifact checksum manifest is `release/SHA256SUMS.txt` and is regenerated after packaging.
