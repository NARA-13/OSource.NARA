# Security model — OSource 0.4.0

**No third-party download is guaranteed safe. This is an unsigned, unaudited preview.**

## Trust boundaries
The Windows host contains a Go backend and an embedded, local WebView2 frontend. The release host binds to an ephemeral IPv4 loopback port, validates the expected Host, and requires a random per-process 256-bit request token for API access. Cross-origin API requests are rejected. Mutations require POST with JSON. A restrictive Content Security Policy blocks external scripts, plugins and forms. Remote text is rendered as escaped text rather than HTML. The token is not a defense against malicious same-user software, which already shares the process/file privilege boundary.

The development preview deliberately binds to all interfaces for a proxied sandbox and disables native OS operations. It is **not a remote administration or multi-user service**. Do not expose it or use it with production personal data.

## Download policy
1. The frontend sends a repository name and asset ID, not an arbitrary destination URL.
2. The backend validates the repository identifier and re-resolves the asset from GitHub metadata.
3. Managed URLs must be HTTPS `github.com/.../releases/download/...` assets.
4. Redirects are limited and must remain on HTTPS. TLS certificate validation remains enabled.
5. DNS results are checked and the selected public IP is dialed directly to avoid a second independent hostname resolution. Loopback, private, link-local and non-global addresses are blocked.
6. Each transfer gets a unique subdirectory. Remote names are sanitized. Bytes stream to a `.part` file rather than to an executable-ready final file.
7. Transfer sizes and Content-Range are validated. Ignored Range requests restart with truncation. ETag/Last-Modified are used as If-Range validators when supplied.
8. Supported file extensions and basic magic headers are checked. A calculated SHA-256 is compared with the GitHub asset digest when one is provided. A mismatch blocks completion.
9. Only after checks does the partial file become the final file. On Windows, Internet-zone metadata is attempted and Authenticode status is read using a hidden, bounded PowerShell process. Untrusted paths are passed through an environment variable to `-LiteralPath`, not interpolated into PowerShell code.
10. Nothing executes automatically. Before executable launch, the file is rehashed; a native confirmation explains the source, hash and signature status. Standard Windows ShellExecute preserves normal operating-system behavior. No elevation or security-warning bypass is requested by OSource.

## Discovery and image boundary
Remote catalogs are untrusted discovery, not download authorization or safety ratings. Each adapter maps to explicit kinds: project, website, discussion, editor extension or free-to-play game. Only separately resolved GitHub releases can be downloaded by OSource. Community URLs open externally; downloaded files still never run automatically.

Thumbnail requests require the boot token and enabled preview preference. Target URLs exclude query strings, fragments, credentials, explicit ports and private IPs. Capture/publisher requests use public-address-pinned HTTPS, bounded redirects, request timeouts, maximum sizes, 2-worker concurrency and local caching. Metadata HTML is parsed, never executed. PNG/JPEG/WebP dimensions and near-uniform blank captures are checked. Image decoding is not an independent security audit. A provider rendering a public page does not get OSource’s cookies, filesystem or native privileges.

Public feeds/API denials are respected; 403/429 create persisted cooldowns. No authentication, CAPTCHA, paywall, anti-bot or access-control bypass is implemented.

## Limits
- A digest from a compromised publisher/repository can still match malicious software. A valid signature identifies a signer, not harmless behavior. Size and header checks are not deep file validation.
- Internet-zone metadata depends on filesystem support (typically NTFS alternate data streams). Windows AV/SmartScreen behavior depends on system configuration. OSource does not itself scan with a malware engine.
- Archive content is not inspected or extracted. The user must review and extract it with a trusted tool.
- Library detection is heuristic. Registry DisplayIcon entries and Start Menu shortcuts are user/installer-controlled references. Launch is deliberate, but an imported shortcut can target something unexpected. Missing detection checks the shortcut file, not its target.
- There remains a same-user filesystem race between validation and Windows execution; this app is not a sandbox for adversarial local software. Do not grant downloaded software trust merely because it appears in the library.
- The client has connection/header timeouts and explicit transfer cancellation. A server can stall a response body until you pause/cancel; there is no universal per-body idle timeout.
- Remote metadata and dependency versions need ongoing maintenance. No independent security audit was performed.

## Responsible disclosure
No public OSource repository or security mailbox was supplied for this release. Report privately to the organization/person distributing your copy. Provide version, minimal reproduction, affected source URL and impact. Do not submit private user data or active malicious payloads. A real private disclosure contact and a signed release process are production release gates.

## Dependency and distribution policy
Resolved versions and checksums are in `go.mod`/`go.sum`. Actual dependency license texts accompany the source and installer. The Windows executable and installer are unsigned. There is no automatic update mechanism or invented update endpoint. Never instruct users to turn off SmartScreen or antivirus to make a release run.

## New directories in 0.4.0
VibeTopList HTML is read only from the fixed public RPG category and its second page after checking the source robots policy. Longest matching Allow/Disallow rules, wildcard/end anchors and OSource-specific groups are supported. Unreadable/stale policy or a requested crawl delay pauses automatic HTML indexing. At most two bounded pages are read, with 12-hour caching. Unrecognized page/README formats are errors, not silently successful fabricated catalogs.

Foundplay uses only its documented public API with a 25-result cap. Returned links must stay on `foundplay.io/games/`; tracking query parameters are removed without replacing the required link back. Awesome AI Games extracts only valid public HTTPS game headings, not arbitrary auxiliary README links. No game repository or Windows installer is inferred from an AI-game directory entry. New adapters use the existing public-address-pinned HTTPS client and persistent denial/rate-limit cooldowns.

The wiki reference has no ingestion or automatic download path. It is not a legal-rights or safety endorsement. Actual managed downloads still require re-resolved GitHub release asset metadata and explicit consent.
