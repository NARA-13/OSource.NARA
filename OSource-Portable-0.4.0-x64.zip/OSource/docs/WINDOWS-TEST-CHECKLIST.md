# Windows acceptance checklist — NOT YET RUN

Run on clean Windows 10 x64 and Windows 11 x64 systems before production distribution. Record OS build, WebView2 version, architecture, filesystem type and actual results. A Linux cross-build or Chromium browser test is not a substitute for these checks.

| Check | Windows 10 x64 | Windows 11 x64 |
|---|---|---|
| Installer opens as current user without elevation | Not run | Not run |
| Custom install directory works | Not run | Not run |
| Optional desktop and Start Menu shortcuts follow selection | Not run | Not run |
| Windows Settings shows OSource uninstall entry | Not run | Not run |
| App opens with WebView2 installed, no browser window needed | Not run | Not run |
| Missing WebView2 produces the native prerequisite prompt | Not run | Not run |
| App icon, title bar, minimize/maximize/close, 100/150/200% display DPI | Not run | Not run |
| Second instance reports data-directory lock gracefully | Not run | Not run |
| Ctrl+K, arrow keys, Enter, Escape and modal focus trap | Not run | Not run |
| Windows installed fonts enumerate and apply | Not run | Not run |
| Native file picker imports a known `.exe` and `.lnk` with spaces/Unicode | Not run | Not run |
| Best-effort registry/Start Menu detection is labeled accurately | Not run | Not run |
| Known harmless app launches; folder opens; bad/moved reference errors | Not run | Not run |
| Removing an entry leaves original files untouched | Not run | Not run |
| Live repository search and stable release selection work | Not run | Not run |
| Windows asset downloads to configured local folder | Not run | Not run |
| Pause/resume across close/reopen and server restart behavior | Not run | Not run |
| Active-transfer window close asks for consent | Not run | Not run |
| Unavailable URL, full disk, denied folder and broken internet fail clearly | Not run | Not run |
| Authenticode status reads correctly for signed/unsigned samples | Not run | Not run |
| NTFS Internet-zone ADS is present after download | Not run | Not run |
| Completed-file tamper is rejected by rehash before launch | Not run | Not run |
| Native installer confirmation defaults to No | Not run | Not run |
| No third-party file executes without explicit approval | Not run | Not run |
| Normal Windows security prompts remain enabled | Not run | Not run |
| Default browser receives website URL; no remote page runs in privileged view | Not run | Not run |
| JSON exports save via WebView2 download handling | Not run | Not run |
| Settings/history/library survive app restart | Not run | Not run |
| Offline cached catalog and local library remain usable | Not run | Not run |
| Uninstall removes only OSource program files and selected shortcuts | Not run | Not run |
| Local data, downloads and other applications survive uninstall | Not run | Not run |
| Reinstall preserves existing data | Not run | Not run |
| Upgrade from 0.1/0.2/0.3 preserves library, favorites and selected blue accent | Not run | Not run |
| Blue affects surfaces/controls in light/dark and persists after rapid changes | Not run | Not run |
| Five-source filtering/paging distinguishes projects, discussions, games and extensions | Not run | Not run |
| Website thumbnails, Unavailable state, opt-out and cache clearing | Not run | Not run |
| Saved discoveries survive restart and appear in global search | Not run | Not run |
| Community website/app picks, source links and saved recommendation provenance | Not run | Not run |
| New VibeTopList, Foundplay and Awesome AI Games sources and bookmarks | Not run | Not run |
| r/Piracy wiki opens externally and never appears as an imported inventory | Not run | Not run |
| App and Windows reduced-motion controls disable hover/entrance effects | Not run | Not run |
| Page changes preserve the sidebar and behave smoothly at 100/150/200% DPI | Not run | Not run |

## Recommended safe download test
Use a small official release such as `jqlang/jq`'s Windows x64 asset. Verify its source URL and digest. You do not need to execute it to validate the download path. Use a separately known harmless local application to test launcher behavior. Do not lower Windows protections to complete a test.

## Before publishing
Set up an owned repository, issue tracker, responsible disclosure address, release provenance and signing policy. Test installer upgrade/repair behavior, accessibility, network faults, disk exhaustion and large downloads. Review deferred features in FEATURE-MATRIX.md rather than presenting them as implemented.
