# Community picks — OSource 0.3.0

Curated **2026-10-26**. The user asked for useful/fun websites and apps from Reddit recommendations, and opted to have suitable threads found rather than supplying a specific megathread. The result is **28 websites and 12 desktop project references**, linked to public recommendation discussions. This is a dated, bundled editorial selection, not a live scrape of all comments or a fabricated universal megathread catalog.

## Using the collection
- Websites → Explore: All / Useful / Play / Make / Learn / Explore. Search is local and immediate. Cards load 12 at a time.
- Surprise me chooses a matching item and opens its details. Nothing opens externally until you choose to open it.
- Store → Community picks: 12 desktop projects. View releases uses the existing live GitHub detail and consent-based download pipeline.
- Each card links to its Reddit thread. Details show original source, curation date and a license/pricing caveat. My websites bookmarks retain the original recommendation source.
- Existing personal websites are unchanged. The new Explore collection is separate; save only what you want.

## Provenance
The links below identify the public threads in which these names were recommended. Descriptions in OSource are original editorial summaries rather than verbatim comments. URLs and classifications are not security endorsements or guarantees of present availability.

| Pick | Collection | Original recommendation thread |
|---|---|---|
| Radio Garden | Explore | [14](https://www.reddit.com/r/AskReddit/comments/15ruo7k/whats_an_extremely_useful_website_most_people/) |
| Earth Nullschool | Explore | [2](https://www.reddit.com/r/Internet/comments/1velx6c/share_the_coolestmost_fascinating_websites_you/) |
| Chrome Music Lab | Make | [4](https://www.reddit.com/r/WeAreTheMusicMakers/comments/6t9j2c/sites_where_you_can_play_with_audio/) |
| Photopea | Useful | [1](https://www.reddit.com/r/NoStupidQuestions/comments/1cdil2i/what_free_software_is_so_good_you_cant_believe/) |
| Nicky Case | Learn | [2](https://www.reddit.com/r/Internet/comments/1velx6c/share_the_coolestmost_fascinating_websites_you/) |
| Little Alchemy | Play | [10](https://www.reddit.com/r/AskReddit/comments/fy2j5o/whats_a_good_website_to_waste_a_whole_night_on/) |
| Sandspiel | Play | [20](https://www.reddit.com/r/AskGames/comments/1gull87/what_are_some_goodfunweird_web_browser_games_to/) |
| Neal.fun | Play | [2](https://www.reddit.com/r/Internet/comments/1velx6c/share_the_coolestmost_fascinating_websites_you/) |
| Patatap | Make | [10](https://www.reddit.com/r/AskReddit/comments/fy2j5o/whats_a_good_website_to_waste_a_whole_night_on/) |
| Typatone | Make | [4](https://www.reddit.com/r/WeAreTheMusicMakers/comments/6t9j2c/sites_where_you_can_play_with_audio/) |
| Slow Roads | Play | [24](https://www.reddit.com/r/Design/comments/1idu38d/what_are_the_craziestmost_creative_websites_youve/) |
| Zoomquilt | Explore | [21](https://www.reddit.com/r/AskReddit/comments/1if14ac/what_are_some_underrated_websites_youve_stumbled/) |
| Pointer Pointer | Play | [21](https://www.reddit.com/r/AskReddit/comments/1if14ac/what_are_some_underrated_websites_youve_stumbled/) |
| Freerice | Learn | [23](https://www.reddit.com/r/AskReddit/comments/1bn3nu3/what_are_some_really_fun_websites_for_when_youre/) |
| WindowSwap | Explore | [8](https://www.reddit.com/r/AskReddit/comments/1pl4mjk/whats_the_most_fun_website_you_found_on_the/) |
| Bored Button | Play | [3](https://www.reddit.com/r/ifyoulikeblank/comments/1i6m4d8/iyl_if_you_like_the_website_nealfun_you_will_like/) |
| The Useless Web | Play | [3](https://www.reddit.com/r/ifyoulikeblank/comments/1i6m4d8/iyl_if_you_like_the_website_nealfun_you_will_like/) |
| Khan Academy | Learn | [12](https://www.reddit.com/r/bestofinternet/comments/1gvtr09/what_are_some_useful_websites_most_people_dont/) |
| Wolfram Alpha | Useful | [14](https://www.reddit.com/r/AskReddit/comments/15ruo7k/whats_an_extremely_useful_website_most_people/) |
| Unsplash | Make | [14](https://www.reddit.com/r/AskReddit/comments/15ruo7k/whats_an_extremely_useful_website_most_people/) |
| Ninite | Useful | [14](https://www.reddit.com/r/AskReddit/comments/15ruo7k/whats_an_extremely_useful_website_most_people/) |
| Have I Been Pwned | Useful | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| LibriVox | Learn | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| PortableApps | Useful | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| PCGamingWiki | Useful | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| Speedrun.com | Explore | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| AlternativeTo | Useful | [10](https://www.reddit.com/r/AskReddit/comments/y2m5ot/what_are_some_free_online_tools_everyone_should/) |
| The Evolution of Trust | Learn | [2](https://www.reddit.com/r/Internet/comments/1velx6c/share_the_coolestmost_fascinating_websites_you/) |
| ShareX | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| LocalSend | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| OBS Studio | Apps | [1](https://www.reddit.com/r/NoStupidQuestions/comments/1cdil2i/what_free_software_is_so_good_you_cant_believe/) |
| Rufus | Apps | [1](https://www.reddit.com/r/NoStupidQuestions/comments/1cdil2i/what_free_software_is_so_good_you_cant_believe/) |
| Audacity | Apps | [1](https://www.reddit.com/r/NoStupidQuestions/comments/1cdil2i/what_free_software_is_so_good_you_cant_believe/) |
| Godot Engine | Apps | [1](https://www.reddit.com/r/NoStupidQuestions/comments/1cdil2i/what_free_software_is_so_good_you_cant_believe/) |
| NAPS2 | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| NanaZip | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| Playnite | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| Kando | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| HandBrake | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |
| Flameshot | Apps | [9](https://www.reddit.com/r/AskReddit/comments/1s6bl5p/what_free_software_is_so_good_you_cant_believe/) |

## Boundaries
Some websites have advertising, optional paid plans, accounts, geographic restrictions, flashing visuals or continuous motion; relevant caveats are retained in each item’s details. Their behavior is controlled by the publisher, not OSource. A screenshot provider can return an access challenge or fail; thumbnails are not a website-availability audit. Do not bypass a website’s access controls.

The source archive includes machine-readable provenance in `research/community-picks.json` and the generator `scripts/update-community.py`. Community data filtering makes no Reddit request. The independent live Reddit adapter remains recent-RSS-feed based, with cache/cooldown and honest failure states. It is not represented as megathread comment search.
