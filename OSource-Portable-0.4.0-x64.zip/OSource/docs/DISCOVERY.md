# Live discovery and website previews

## Scope and scale
OSource now queries eight public catalog sources on demand and exposes one external-only reference. The table below records the original five-source 0.2.0 run; see SOURCES-0.4.md for the additional sources and current scope. It does not bundle a fabricated 200,000-entry catalog or claim that repository search totals are installable Windows applications. The broad source search space exceeds 200,000 records, but each query is paginated and rate limited. Results may overlap, be unrelated, or be incompatible with Windows.

Observed real results during the 2026-10-26 implementation tests (not fixed inventory promises):

| Source | Observed source-scoped count | Meaning and limitation |
|---|---:|---|
| GitHub | approximately 26,438,436 | Broad repository matches; GitHub marked the total approximate. Includes documentation, libraries and non-Windows code. Maximum 1,000 accessible results per query; narrow the query for other repositories. |
| FMHY | 6,558 | Unique primary links extracted from ten published tools/education directory sections, not the entire FMHY site. |
| Reddit | 25 | Recent posts in the fetched public r/opensource RSS feed, not Reddit-wide search. Games uses r/webgames. |
| Open VSX | 20,164 | Editor extensions; require a compatible editor and individual license review. |
| FreeToGame | 419 | Free-to-play PC/browser games, not verified open-source software. Accounts, launchers and purchases may apply. |

The first integration response returned 60 interleaved records; subsequent views correctly used cached results. Reddit briefly denied a request in an earlier run, then its public feed was available in a later run. These are observed remote responses, not uptime guarantees. Raw execution evidence is in `test-logs/discovery-browser-0.2.0.txt`.

## Usage
Store offers query, source, kind and sorting controls, plus Load more. All sources requests up to 12 records/source/page; a single source requests up to 30. Source status, scope, limitations and timestamps remain attached to results. Incompatible source/kind selections reset the other filter to a compatible scope. Save records for later; Ctrl+K includes loaded and saved discoveries. Websites → Live directory offers FMHY links, GitHub web projects and browser games, with bookmarking into My websites.

GitHub records open the existing repository/release details and consent-based download flow. Community discussions, extension listings and game pages open their original HTTPS sites. No arbitrary community link can silently become an executable download. A source count is not safety, licensing or Windows-compatibility verification.

## Fetch/cache policy
- GitHub discovery search: 1 hour; project/quick-search metadata: 6 hours; latest releases: 1 hour.
- FMHY: 12 hours; primary bullet links from ten tools/education Markdown sections. Fetches are bounded and parsed as data, not executed.
- Reddit public feeds: 15 minutes; query filtering is local to fetched recent posts.
- Open VSX: 1 hour; source API query and offset paging.
- FreeToGame: 6 hours; local query/platform filtering of the public game catalog.
- Stale cached data is returned after a failed refresh when available. Source failures do not discard other sources.
- The multi-source HTTP adapter persists 403/429 cooldowns, honoring bounded Retry-After values; it never bypasses blocks. GitHub also reports its public API failures through the existing cache adapter. No embedded token or login is required.
- No aggressive background crawl, account-based ingestion or complete local index is performed. Results accumulate only as the user loads pages. DOM virtualization is not implemented; very long browsing sessions can grow the rendered list.

## Thumbnails
Website cards request actual cached thum.io captures. If the service fails or returns a near-uniform image, OSource tries the website’s public OpenGraph/Twitter image. That fallback is publisher imagery, not necessarily a screenshot. Empty/failed results show **Preview unavailable** with a normal website-open action; synthetic illustrations are never mislabeled as live captures.

Live checks confirmed an 800×333 Excalidraw capture and a 1614×842 Radio Garden publisher-image fallback. Neal.fun did not provide a usable image in this environment and correctly showed Unavailable. Not every website can be captured.

These are **still thumbnails**, not real-time embedded websites. The local cache lasts up to 24 hours, is capped at 200 files/64 MiB, and permits at most two concurrent captures. Failed targets have a short cooldown. Queries/fragments, credentials, ports and private targets are excluded. Thumbnail display is enabled by default; disable it or clear its local cache in Settings → Privacy. Providers can maintain their own caches. See PRIVACY.md and SECURITY.md.

## Independent source attribution
GitHub: https://github.com/ · FMHY: https://fmhy.net/ · Reddit: https://www.reddit.com/ · Open VSX: https://open-vsx.org/ · **Data provided by FreeToGame:** https://www.freetogame.com/ · Screenshot provider: https://www.thum.io/

OSource is independent of these sources. Their content, terms, limits and availability remain theirs. AlternativeTo, SourceForge and Android-only F-Droid are external references, not implemented Windows catalog adapters.
